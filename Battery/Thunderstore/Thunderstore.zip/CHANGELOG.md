# v1.0.1
This mode Unlimited battery setting, Battery Life allows you to change for the following products

- FlashLight
- ProFlashLight
- LaserPointer
- WalkieTalkie
- Jetpack
- PatcherTool
- BoomboxItem
- HandheldRadar **[LethalThings]**
- HackingTool **[LethalThings]**

# v1.0.2
Updated README.md and (Thunderstore)manifest.json
Added CHANGELOG.md

# v1.0.3
The code has been rewritten.

# v1.0.4
Changes for Thunderstore. There is no change in mode.