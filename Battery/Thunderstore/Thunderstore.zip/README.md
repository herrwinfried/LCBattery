# Battery

Insufficient power? No problem!

## Required

- [BepInEx 5.4.22](https://github.com/BepInEx/BepInEx/releases/tag/v5.4.22)
- [LethalThings 0.8.8](https://thunderstore.io/c/lethal-company/p/Evaisa/LethalThings/)
    - [HookGenPatcher 0.0.5](https://thunderstore.io/c/lethal-company/p/Evaisa/HookGenPatcher/)
    - [LethalLib 0.8.0](https://thunderstore.io/c/lethal-company/p/Evaisa/LethalLib/)
